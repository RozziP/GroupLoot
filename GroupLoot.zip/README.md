##Group Loot##

Builds upon Solstic3's shared loot mod
Adding more players to a team no longer increases the number of interactable items that spawn.

Copy Assembly-CSharp.dll into Risk of Rain2 -> Risk of Rain 2_Data -> Managed